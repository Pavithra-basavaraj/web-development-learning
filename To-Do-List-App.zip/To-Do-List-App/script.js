// Access DOM elements
const taskInput = document.getElementById("taskInput");
const addBtn = document.getElementById("addBtn");
const taskList = document.getElementById("taskList");

// Add button event listener
addBtn.addEventListener("click", addTask);

// Function to add a new task
function addTask() {
  const taskText = taskInput.value.trim();

  if (taskText === "") {
    alert("Please enter a task!");
    return;
  }

  // Create new list item (li)
  const li = document.createElement("li");

  // Create task text
  const span = document.createElement("span");
  span.textContent = taskText;

  // Create delete button
  const deleteBtn = document.createElement("button");
  deleteBtn.textContent = "Delete";
  deleteBtn.classList.add("delete");

  // Append text and delete button to li
  li.appendChild(span);
  li.appendChild(deleteBtn);

  // Add li to ul
  taskList.appendChild(li);

  // Clear input box
  taskInput.value = "";

  // Toggle complete when clicking on text
  span.addEventListener("click", function () {
    span.classList.toggle("done");
  });

  // Delete task
  deleteBtn.addEventListener("click", function () {
    li.remove();
  });
}

